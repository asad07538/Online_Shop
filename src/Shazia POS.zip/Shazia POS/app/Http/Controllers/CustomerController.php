<?php

namespace App\Http\Controllers;

use App\Customer;
use Brian2694\Toastr\Facades\Toastr;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = Customer::latest()->where('shop_id',Auth::user()->shops[0]->id)->get();
        return view('admin.customer.index', compact('customers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.customer.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->except('_token');
        $rules = [
            'name' => 'required | min:3',
            'email' => 'required| email | unique:customers',
            'phone' => 'required | unique:customers',
            'address' => 'required',
            'city' => 'required',
            // 'photo' => 'required | image',
        ];

        $validation = Validator::make($inputs, $rules);
        if ($validation->fails())
        {
            return redirect()->back()->withErrors($validation)->withInput();
        }

        // $image = $request->file('photo');
        // $slug =  Str::slug($request->input('name'));
        // if (isset($image))
        // {
        //     $currentDate = Carbon::now()->toDateString();
        //     $imageName = $slug.'-'.$currentDate.'-'.uniqid().'.'.$image->getClientOriginalExtension();
        //     if (!Storage::disk('public')->exists('customer'))
        //     {
        //         Storage::disk('public')->makeDirectory('customer');
        //     }
        //     $postImage = Image::make($image)->resize(480, 320)->stream();
        //     Storage::disk('public')->put('customer/'.$imageName, $postImage);
        // } else
        // {
        //     $imageName = 'default.png';
        // }

        $customer = new Customer();
        $customer->name = $request->input('name');
        $customer->email = $request->input('email');
        $customer->phone = $request->input('phone');
        $customer->address = $request->input('address');
        $customer->shop_id = Auth::user()->shops[0]->id;
        $customer->city = $request->input('city');
        // $customer->shop_name = $request->input('shop_name');
        // $customer->photo = $imageName;
        $customer->save();

        Toastr::success('Customer Successfully Created', 'Success!!!');
        return redirect()->route('admin.customer.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show(Customer $customer)
    {

        $total=0;
        $paid=0;
        $due=0;

        foreach($customer->orders as $order){
            $total=$order->sub_total;
            $paid=$order->pay;
            $due=$order->due;
        }


        return view('admin.customer.show', compact('customer','total','paid','due'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer $customer)
    {
        return view('admin.customer.edit', compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Customer $customer)
    {
        $inputs = $request->except('_token');
        $rules = [
            'name' => 'required | min:3',
            'email' => 'required| email',
            'phone' => 'required',
            'address' => 'required',
            'city' => 'required',
            // 'photo' => 'image',
        ];

        $validation = Validator::make($inputs, $rules);
        if ($validation->fails())
        {
            return redirect()->back()->withErrors($validation)->withInput();
        }

        // $image = $request->file('photo');
        // $slug =  Str::slug($request->input('name'));
        // if (isset($image))
        // {
        //     $currentDate = Carbon::now()->toDateString();
        //     $imageName = $slug.'-'.$currentDate.'-'.uniqid().'.'.$image->getClientOriginalExtension();
        //     if (!Storage::disk('public')->exists('customer'))
        //     {
        //         Storage::disk('public')->makeDirectory('customer');
        //     }

        //     // delete old photo
        //     if (Storage::disk('public')->exists('customer/'. $customer->photo))
        //     {
        //         Storage::disk('public')->delete('customer/'. $customer->photo);
        //     }

        //     $postImage = Image::make($image)->resize(480, 320)->stream();
        //     Storage::disk('public')->put('customer/'.$imageName, $postImage);
        // } else
        // {
        //     $imageName = $customer->photo;
        // }

        $customer->name = $request->input('name');
        $customer->email = $request->input('email');
        $customer->phone = $request->input('phone');
        $customer->address = $request->input('address');
        $customer->city = $request->input('city');
        // $customer->shop_name = $request->input('shop_name');

        // $customer->photo = $imageName;
        $customer->save();

        Toastr::success('Customer Successfully Updated', 'Success!!!');
        return redirect()->route('admin.customer.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customer $customer)
    {
        if (Storage::disk('public')->exists('customer/'. $customer->photo))
        {
            Storage::disk('public')->delete('customer/'. $customer->photo);
        }
        $customer->delete();
        Toastr::success('Customer Successfully Deleted', 'Success!!!');
        return redirect()->route('admin.customer.index');
    }
}
