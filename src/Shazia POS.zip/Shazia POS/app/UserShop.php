<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserShop extends Model
{
    //
}
