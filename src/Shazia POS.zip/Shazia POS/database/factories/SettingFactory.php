<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Setting;
use Faker\Generator as Faker;

$factory->define(Setting::class, function (Faker $faker) {
    return [
        //
    ];
});
