<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Advanced_Salary;
use Faker\Generator as Faker;

$factory->define(Advanced_Salary::class, function (Faker $faker) {
    return [
        //
    ];
});
