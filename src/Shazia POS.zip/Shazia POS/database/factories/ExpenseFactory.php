<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Expense;
use Faker\Generator as Faker;

$factory->define(Expense::class, function (Faker $faker) {
    return [
        //
    ];
});
