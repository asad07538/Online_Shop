<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Salary;
use Faker\Generator as Faker;

$factory->define(Salary::class, function (Faker $faker) {
    return [
        //
    ];
});
