<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Supplier;
use Faker\Generator as Faker;

$factory->define(Supplier::class, function (Faker $faker) {
    return [
        //
    ];
});
